# AXM Stateborn RPG Lab v0.2.0 — Test Report

Tested: 2026-09-04

## Result

**PASS within the v0.2.0 experimental boundary**

The deterministic engines, sparse logical field, offline browser bundle, counterfactual branches, replay, and sealed restore passed. This does not upgrade the claim to “RPG generated.”

## Automated verification

25 / 25 tests passed: the original 12 integrity tests plus 13 living-world tests covering:

- one million logical cells beginning mostly asleep;
- deterministic on-demand cell materialization;
- autonomous reciprocal sharing after a player share;
- a causally different wait/unanswered-need branch;
- the same share transform for player and autonomous actors;
- indexed rule wake-up without scanning logical cells;
- sparse gather override rather than field materialization;
- stale refusal without autonomy;
- idempotent operation IDs;
- atomic rollback across player and autonomous draft state;
- exact replay of autonomous decisions;
- sealed save tamper refusal and replay restore;
- 1-million versus 100-million logical scale changing the root commitment, not materialization demand.

Static validation passed for eight required files, five JavaScript files, local entrypoints, classic bundle syntax, hosting declaration, and absence of external runtime dependencies.

## Scale measurements

Runtime: Node v24.19.0. Timings and heap deltas are environment-specific; the useful result is the growth shape.

| Architecture | Logical cells | Construct | One action | Heap delta | Materialized | Woken | Replay |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| v0.1 full graph | 50,000 dormant + active world | 1869.753 ms | 2321.414 ms | 140.278 MiB | all | 5 | not benchmarked |
| v0.2 sparse field | 1,048,576 | 2.134 ms | 27.589 ms | 0.649 MiB | 2 | 4 | PASS |
| v0.2 sparse field | 100,000,000 | 0.608 ms | 4.177 ms | 0.382 MiB | 2 | 4 | PASS |

The 100-million case is not “faster” evidence; JIT and garbage collection make isolated absolute timings noisy. It shows that untouched logical cells are represented by a fixed generator commitment rather than copied per action.

## Browser interaction verification

Tested against the delivered standalone files:

- root loaded at revision 0 with 1,048,579 logical nodes;
- the 7 × 7 viewport materialized 49 cells while 1,048,527 remained sleeping;
- living probe advanced one turn and showed two actor events;
- player event: share food with Rhea;
- autonomous event: Rhea share water with player, cause `remembered_relation`;
- projected situation: `mutual_aid`, evidence events 0 and 1;
- four nodes woke and three produced canonical deltas;
- exact replay: PASS;
- sealed local save → reset → load restored revision, situation, and digest;
- wait counterfactual produced Rhea's autonomous food request and `unanswered_need`;
- method boundary remained explicit;
- 49 map cells and seven current action controls rendered;
- no horizontal overflow at the 1348-pixel verification viewport;
- application-origin browser warnings/errors: none. Browser-extension metadata errors were excluded as non-application noise.

## Counterfactual digests

Using browser seed `AXM-STATEBORN-001`:

```text
share -> mutual_aid:
01e4f7849f947df11e8ca9e60d72961c3229e1060d592d708d322163e65e1bf2

wait -> unanswered_need:
9a51e0a57558f1151f1ce22e97687701d415179d4ade31c498134a0537964b36
```

Both replay exactly; their inequality is the evidence that the input state change altered the downstream branch.

## Not tested or not proven

- fun, long-term play, narrative quality, or world-scale content richness;
- millions of simultaneously active actors or changed cells;
- concurrency, network latency, adversarial peers, or distributed consensus;
- portable human-state composition or consent enforcement;
- state-only machine coordination;
- OS boot or USB hardware behavior;
- mobile browser interaction in the supervised browser;
- GitHub CI, PR, merge, or canon state.
