# AXM Stateborn RPG Lab v0.4.0 — Test Report

Tested: 2026-09-04

## Result

**PASS within the v0.4.0 experimental boundary**

The new coexistence engine and surface, retained curiosity and relational
experiments, sparse fields, proposal refusals, and replay checks passed. This
does not prove machine consciousness, participation by a real AI model,
open-ended emergence, or a generated RPG.

## Automated verification

49 / 49 tests passed:

- 12 original canonical-state and receipt-integrity tests;
- 13 sparse living-world and autonomous-reciprocity tests;
- 11 curiosity-loop tests;
- 13 coexistence tests.

The coexistence tests verify:

- authored genesis co-location creates no event or adventure thread;
- human, machine, and AI-compatible seats use validated world transforms;
- machine policy input excludes reward, success, damage, vitality, bloom,
  scar, observer, and outcome fields;
- fabricated observer state cannot alter the machine's next choice;
- the offline AI stand-in is labelled and receives a bounded view;
- invalid external proposals are refused without a fallback or AI event;
- valid external proposals commit only after local validation;
- thread projections bind event IDs from intersecting roles;
- stale or invalid human actions stop the whole cycle before other seats act;
- operation IDs are idempotent;
- exact replay covers stand-in, accepted external, and refused external paths;
- a hundred-million-cell logical field stays sparse in the bounded probe;
- different human choices branch the same genesis.

Static validation passed for 18 required files, three offline HTML entrypoints,
11 JavaScript files, local navigation, the hosting declaration, and absence of
external runtime dependencies.

## Twelve-seed coexistence probe

Parameters: 12 deterministic seeds × 64 cycles, producing 192 seat events per
run under the scripted-human probe.

- exact replay: 12 / 12 PASS;
- clean machine policy views: 12 / 12 PASS;
- runs containing both growth and damage: 12 / 12;
- runs containing shared sites: 12 / 12;
- runs containing three-way marks: 12 / 12;
- changed cells per run: 9–18;
- materialized cells per run: 22–43;
- final health drift: −12 to +7;
- evidence-backed threads after 64 cycles: 17–25.

These results show mechanism repeatability with different consequences. The
shared genesis fixture, scripted human plan, four signals, policies, world
transform, and projection thresholds are authored.

## Browser interaction verification

Tested against the delivered `dist/coexistence.html` classic bundle:

- revision-zero genesis displayed the authored-fixture disclosure and no
  adventure thread;
- one human `signal open` cycle committed one human, one machine, and one
  labelled stand-in event;
- only after those receipts existed did `encounter`, `shared_site`, and
  `three_way_mark` appear;
- a non-adjacent external coordinate proposal was refused, created no AI
  event, and reported that no fallback was used;
- exact replay reconstructed the two mixed proposal cycles;
- reset restored a zero-event, zero-thread genesis;
- the 12-cycle UI probe completed with 36 events and eight evidence-backed
  threads;
- no horizontal overflow occurred at the 1363-pixel verification viewport;
- application-origin browser warnings/errors: none (extension-origin metadata
  warnings were excluded).

## Retained experiments

The v0.3 Curiosity Garden still reproduces its 12-seed outcome-blind novelty
probe. The v0.2 relational lab still reproduces player share → Rhea autonomous
share → `mutual_aid`, while wait → Rhea request → `unanswered_need`.

## Truth boundary

Observed: three differently bounded seats can contribute to one deterministic,
sparse, replayable world while a local referee retains consequence authority
and evidence-gated projections expose where their histories intersect.

Not proven:

- subjective curiosity, machine desire, or mutual understanding;
- participation by a real AI model in the offline build;
- that the result is fun, wise, narratively meaningful, or self-sustaining;
- open-ended novelty or unbounded emergence;
- millions of active actors or changed nodes;
- networked multiplayer, portable human-state composition, or OS/USB behavior;
- GitHub CI, PR, merge, release, or canon state.
