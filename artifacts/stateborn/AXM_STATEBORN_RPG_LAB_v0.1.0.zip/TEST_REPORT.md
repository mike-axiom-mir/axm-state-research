# AXM Stateborn RPG Lab v0.1.0 — Test Report

Tested: 2026-09-04

## Result

**PASS within the v0.1.0 experimental boundary**

The deterministic engine, offline browser bundle, and tested interaction paths passed. This does not upgrade the research claim from “RPG-like fragments observed” to “RPG generated.”

## Automated engine tests

12 / 12 passed:

1. SHA-256 standard vector;
2. canonical object-key ordering;
3. deterministic genesis/root state from the same seed;
4. unavailable interaction refusal without state mutation;
5. stale revision refusal without rebasing;
6. idempotent operation IDs;
7. atomic rollback after invariant failure;
8. evidence-derived identity without class selection;
9. causal node wake/fired/path trace;
10. exact replay reconstruction;
11. sealed save import and tamper refusal;
12. identical state and receipt chains across independent runs.

## Static validation

- required entrypoints: PASS;
- classic standalone browser bundle syntax: PASS;
- readable source-module syntax: PASS;
- local asset references: PASS;
- hosting directory declaration: PASS;
- external delivered runtime dependencies: none found.

## Browser interaction test

Tested against the same standalone files included in `dist`:

- root state loaded at revision 0;
- one truthful nearby pressure thread appeared at root;
- gather action updated inventory and advanced to revision 1;
- adjacent map movement advanced to revision 2;
- sharing with Rhea advanced to revision 3 and projected a responded relation thread;
- full five-transition probe advanced to revision 5;
- final identity projection: `Keeper-shaped`, strength 2;
- final reciprocal signal: food at `c_2_6`, based on `bond_rhea:2`;
- exact replay: PASS, 5 applied events;
- local save → reset → load: restored the same identity and digest;
- method boundary dialog: PASS;
- receipts inspector: 5 ordered applied receipts visible;
- canonical state inspector: correct schema and revision visible;
- application-origin browser warnings/errors: none.

## Probe digest

```text
c6b681117312f60c0ffa119faa0a31986abeadd62e48269ce34ad9e7294256aa
```

Exact replay reconstructed the same digest.

## Repair made during browser testing

The first relation projection incorrectly mapped the abstract need `safety` onto a resource cell. That unsupported signal was removed. Reciprocal location knowledge now requires a resource represented by actual cell state, using an unresolved material need or a receipt-backed exchanged material. An automated test now verifies that the reported cell contains the reported resource.

## Not tested or not proven

- fun, long-term play, or narrative quality;
- large-world performance;
- multiple simultaneous actors;
- portable actor-state composition;
- state-only machine coordination;
- networked multiplayer;
- OS boot or USB hardware behavior;
- mobile browser interaction in the supervised browser;
- GitHub packaging, CI, PR, merge, or canon state.
