import { existsSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const required = ["dist/index.html", "dist/styles.css", "dist/stateborn.bundle.js", "dist/app.js", "dist/engine.js", "dist/world.js", ".openai/hosting.json"];
const failures = [];

for (const relative of required) {
  if (!existsSync(resolve(root, relative))) failures.push(`missing:${relative}`);
}

const html = readFileSync(resolve(root, "dist/index.html"), "utf8");
for (const asset of ["./styles.css", "./stateborn.bundle.js"]) {
  if (!html.includes(asset)) failures.push(`entrypoint-reference:${asset}`);
  if (!existsSync(resolve(root, "dist", asset))) failures.push(`entrypoint-file:${asset}`);
}

for (const relative of ["dist/stateborn.bundle.js", "dist/app.js", "dist/engine.js", "dist/world.js"]) {
  const checked = spawnSync(process.execPath, ["--check", resolve(root, relative)], { encoding: "utf8" });
  if (checked.status !== 0) failures.push(`javascript-syntax:${relative}:${checked.stderr.trim()}`);
}

for (const relative of ["dist/index.html", "dist/styles.css", "dist/stateborn.bundle.js", "dist/app.js", "dist/engine.js", "dist/world.js"]) {
  const contents = readFileSync(resolve(root, relative), "utf8");
  if (/https?:\/\//i.test(contents)) failures.push(`external-dependency:${relative}`);
}

const manifest = JSON.parse(readFileSync(resolve(root, ".openai/hosting.json"), "utf8"));
if (manifest.static?.directory !== "dist") failures.push("hosting-static-directory");

const result = {
  schema: "axm.stateborn.static-validation/v1",
  status: failures.length ? "FAIL" : "PASS",
  filesChecked: required.length,
  javascriptFilesChecked: 4,
  externalDependencies: false,
  failures,
};
console.log(JSON.stringify(result, null, 2));
if (failures.length) process.exitCode = 1;
