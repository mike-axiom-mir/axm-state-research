# AXM Stateborn RPG Lab v0.1.0

Stateborn is a new, isolated research instrument. It tests whether recognizable RPG-like behavior can emerge upward from deterministic state nodes, relation edges, dependency-triggered rules, and atomic transforms.

It is not a claim that AXM has generated a real RPG. The playable browser surface exists so a human can interact with the fabric and inspect the exact causal trace behind every result.

## Current experiment

The engine begins with:

- one canonical world state;
- addressable cell and actor nodes;
- explicit relation edges;
- five ordinary transforms: move, gather, share, raise shelter, and rest;
- seven deterministic perspective nodes;
- five fail-closed invariants;
- an append-only receipt chain with prior and resulting state digests;
- exact replay and sealed local saves.

There is no authored quest and no class selection. Unmet needs are projected as relational threads. Repeated receipt-backed behavior is projected as an identity pattern. Repeated help can cross a relation threshold and cause reciprocal knowledge to appear.

That is an observed state-derived signal, not proof of a satisfying RPG.

## Run locally

Open `dist/index.html` in a modern browser. The delivered surface uses a classic local bundle, so it can be opened directly without a local server. It has no network, account, AI, analytics, or external asset dependency.

Run the deterministic verification with:

```bash
node --test tests/fabric.test.mjs
node tools/validate-static.mjs
```

## Research gates

1. **Single actor + world fabric — implemented for testing.** Determine whether agency, pressure, progression-like identity, relationship, reciprocal response, and persistent world change emerge coherently.
2. **Portable actor-state composition — proposed only.** Project a bounded person-state into another compatible state fabric without fusing ownership or histories.
3. **Machine state language — proposed only.** Test whether two actors coordinate using only state offers, deltas, refusals, and receipts, with no natural-language exchange.
4. **Multiplayer state routing — unproven.** Explore matching compatible actor-state projections and composing a temporary shared world while preserving independent recovery.
5. **State-root USB boot — proposed only.** Treat a sealed recoverable root state as revision zero, then layer hardware projection and portable user/session deltas around it.

## Separation from earlier work

This is not a continuation of the older Threshold Expedition RPG foundation. That earlier evidence informed only general integrity requirements such as atomic transitions, replay, idempotency, and refusal without mutation. No earlier story, RPG model, backend package, or world state is a dependency of Stateborn.

See [docs/STATE_RESEARCH_HANDOFF.md](docs/STATE_RESEARCH_HANDOFF.md) for the future `axm-state-research` lane boundary.
