# AXM Stateborn RPG Lab v0.3.0

Stateborn is a bottom-up research instrument. It asks whether RPG-like situations can arise from deterministic state, actor pressure, relations, memory, generic intent transforms, and consequences—without defining a conventional RPG first.

It is not a claim that AXM has generated a real RPG. The browser surface is a microscope for the state fabric: it shows which nodes woke, which actors acted, what changed, and whether exact replay reaches the same digest.

## Curiosity Garden in v0.3

`dist/curiosity.html` adds a separate mini experiment without replacing the v0.2 relational lab. Six deterministic actors select actions from novelty pressure rather than an outcome reward.

The actor policy may see only:

- terrain and phase;
- unfamiliar neighbouring states;
- how often a context/action pair was tried;
- a short history of observation signatures.

It does not receive health, vitality, growth, damage, bloom, scar, success, or reward fields. Those consequences are projected only for the game observer after an action commits.

Across 12 seeds × 64 steps, every run produced both growth and damage, changed 22–31 sparse cells, created at least one shared echo, kept all policy views free of forbidden outcome fields, and replayed exactly. Ten worlds ended with positive health drift and two with negative drift. This is evidence of a repeatable curiosity-driven change mechanism, not evidence of machine feelings or a self-growing ecology.

## What changed in v0.2

The failed v0.1 scale experiment copied and hashed the whole world on every action. At 50,000 sleeping nodes, one action took about 2.3 seconds and added about 140 MiB in the measured runtime. The node idea was not the bottleneck; global copying was.

v0.2 replaces the materialized world graph with a deterministic sparse field:

- 1,048,576 logical cells and three actors by default;
- cells generated on demand from seed + coordinates;
- only sparse cell overrides become canonical mutable state;
- inactive cells sleep and do no per-turn work;
- dependency indexes wake only rules subscribed to changed state families;
- the player and autonomous actors use the same validated intent transforms;
- actor decisions, causes, events, situations, and digests remain receipt-bound;
- stale revision, duplicate operation, invariant, replay, and save checks remain fail-closed.

## v0.2 relational observation

The lab seed intentionally gives the player food and water pressure, while nearby Rhea has water and food pressure. It supplies conditions, not a quest.

One player `share food` intent produces:

1. the player's share event;
2. Rhea's autonomous `share water` event, caused by the newly remembered relation;
3. a `mutual_aid` situation projected from those two event receipts.

The counterfactual `wait` intent does not produce that result. Rhea instead opens a food request, producing an `unanswered_need` situation and a different digest.

This is a small, causally verified RPG-like situation. It is not evidence of rich emergence, fun, narrative quality, or a finished game.

## Run locally

Open `dist/index.html` for the relational probe or `dist/curiosity.html` for Curiosity Garden. Both classic local bundles require no server, network, account, AI connection, analytics, or external asset.

If Node.js is installed:

```bash
npm test
node tools/benchmark-v01.mjs 0 1000 10000 50000
node tools/benchmark-v02.mjs
node tools/curiosity-probe.mjs 64 12
node tools/validate-static.mjs
```

## Research gates

1. **Sparse living state fabric — implemented for testing.** Measure agency, pressure, relation memory, autonomous reaction, situation projection, and cost growth.
2. **Curiosity without outcome reward — implemented as a mini experiment.** Measure novelty-driven state change while keeping consequences outside the actor policy.
3. **Portable actor-state composition — proposed only.** Project bounded, consented state into another compatible fabric without fusing ownership or history.
4. **Machine state language — proposed only.** Test coordination through state offers, deltas, refusals, and receipts without natural language.
5. **Multiplayer state routing — unproven.** Compose temporary shared worlds while preserving independent recovery and accepted return deltas.
6. **State-root USB boot — conceptual only.** Treat a sealed genesis/root state as revision zero around real firmware, bootloader, kernel, driver, and hardware gates.

## Separation and publication state

This remains isolated from the older Threshold Expedition RPG foundation. Earlier work informed integrity requirements only; no earlier story, world, backend state, or RPG model is a dependency.

No GitHub branch, PR, merge, or canon action has been made. The intended future destination remains a bounded `axm-state-research` lane after GitHub 2FA is ready.

See `docs/ACTION_REPORT_v0.3.0.md`, `docs/CURIOSITY_INCENTIVE_REPORT_v0.3.0.md`, and the retained v0.1/v0.2 reports for the evidence boundary.
