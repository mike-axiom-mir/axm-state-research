# Stateborn → AXM State Research handoff

Status: **LOCAL EXPERIMENT / NOT YET A GITHUB LANE**

This document records the bounded material that may later be added to `axm-state-research` after Mike completes GitHub 2FA. It does not authorize a merge or canon action.

## Research question

Can a game-like experience be assembled upward from a canonical state graph and tiny deterministic perspective nodes, without first specifying a conventional RPG and decomposing it?

## Node contract used through v0.3.0

Each rule node has:

- a stable ID and perspective;
- explicit state-path subscriptions;
- a deterministic condition;
- a deterministic state transform;
- a wake trace even when it produces no delta;
- a fired trace only when canonical state actually changes.

Each player action becomes an atomic transaction:

1. verify operation identity and expected revision;
2. verify the action precondition;
3. apply the proposed transform to a draft state;
4. wake subscribed nodes until a bounded fixed point;
5. verify all invariants;
6. either commit the whole draft or refuse it without mutation;
7. issue a receipt binding prior digest, action, causal trace, resulting digest, and revision.

v0.2 adds a sparse-world boundary: untouched logical cells are recoverable from a root generator commitment rather than copied into each transaction. Only materialized views and changed sparse overrides wake relevant work. Autonomous actors submit the same typed intents through the same validation and transform functions as the player, and their choices and causes are added to the receipt.

v0.3 adds a projection boundary between the actor's action-selection state and the game observer's consequence state. Curiosity actors receive novelty evidence only. Growth, damage, vitality, bloom, scar, and health drift exist outside that policy input. Each receipt preserves both projections so the separation can be audited without letting the outcome become actor authority.

## Current observations to measure

- deterministic world generation from an explicit seed;
- same action chain → same state and receipt chain;
- refused and stale actions leave canonical state unchanged;
- duplicate operation IDs do not repeat effects;
- node wake-up is distinct from node mutation;
- repeated behavior can create a derived identity signal without class selection;
- repeated sharing can create a relationship edge and reciprocal knowledge signal without an authored quest;
- exact replay reconstructs the current digest;
- local save tampering is refused before import.
- increasing untouched logical extent from one million to one hundred million cells does not increase materialized cells or wake count in the bounded probe;
- a player share can cause an autonomous reciprocal share and project `mutual_aid` from two event receipts;
- the wait counterfactual projects `unanswered_need` and a distinct replayable digest.
- a 12-seed curiosity probe keeps forbidden outcome fields out of all policy views while producing mixed observer-visible changes;
- multiple actors can alter the same cell and create a receipt-backed `shared_echo` without natural-language messaging;
- changing observer outcome summaries does not alter the actor's next selected intent.

## Truth boundary

Verified automated behavior is not equivalent to verified fun, narrative coherence, RPG depth, multiplayer safety, or useful generality. Those remain unproven until separate tests measure them.

## Proposed next gates

### Gate 2 — portable actor-state composition

Represent each participant as an independently owned capsule. A shared world receives only a consented projection. Composition must preserve namespaces, source digests, permissions, reversible separation, and conflict receipts. “Merge” must never mean irreversible identity fusion.

### Gate 3 — machine state language

Give two actors a shared problem but no text channel. Allow only typed state offers, requested deltas, accept/refuse responses, and resulting receipts. Measure task completion, message volume, ambiguity, deadlocks, and whether replay reproduces coordination.

### Gate 4 — multiplayer routing

Match compatible actor projections rather than merely accounts or game queues. Compose a temporary shared state, keep each source state independently recoverable, and return only explicitly accepted deltas to each participant.

### Gate 5 — state-root USB boot

Place an immutable, digest-verifiable root starting state on bootable media. Treat firmware, bootloader, kernel, driver discovery, and hardware facts as bounded gates or projections around that root. Keep the user capsule and accepted session deltas independently recoverable. This is a conceptual architecture only; no UEFI, Secure Boot, driver, encryption, or storage-atomicity implementation has been tested here.

## Exclusions for the future lane

- no automatic canon or merge;
- no claim of real RPG generation from the current probe;
- no import of older Threshold story/world/backend state;
- no hidden natural-language coordination inside the state-language test;
- no blind cross-user state merge;
- no authority granted merely because a node produced a recommendation.
- no claim that a genesis/root state alone makes an OS bootable.
