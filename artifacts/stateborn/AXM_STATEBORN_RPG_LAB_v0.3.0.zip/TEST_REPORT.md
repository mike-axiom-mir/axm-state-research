# AXM Stateborn RPG Lab v0.3.0 — Test Report

Tested: 2026-09-04

## Result

**PASS within the v0.3.0 experimental boundary**

The new curiosity loop, retained v0.2 relational engine, sparse field, offline browser bundles, counterfactuals, and replay checks passed. This does not prove machine curiosity, consciousness, a self-growing ecology, or a generated RPG.

## Automated verification

36 / 36 tests passed:

- 12 original canonical-state and receipt integrity tests;
- 13 sparse living-world and autonomous-reciprocity tests;
- 11 curiosity-loop tests.

The curiosity tests verify:

- policy input excludes reward, success, damage, vitality, bloom, scar, observer, and outcome fields;
- fabricated observer damage/success summaries cannot alter the next actor choice;
- identical seed and genesis produce identical choices, receipts, and digest;
- actors use both movement and multiple state signals;
- one blind loop produces both game-visible growth and damage;
- world change stays sparse and slower than loop steps;
- multiple actors can leave a shared echo without messaging;
- operation IDs are idempotent;
- stale steps refuse before action selection;
- exact replay reconstructs choices and observer consequences;
- increasing untouched logical extent does not materialize extra cells.

Static validation passed for 13 required files, two offline HTML entrypoints, eight JavaScript files, local navigation, hosting declaration, and absence of external runtime dependencies.

## Twelve-seed curiosity probe

Parameters: 12 deterministic seeds × 64 steps each.

- exact replay: 12 / 12 PASS;
- clean actor policy views: 12 / 12 PASS;
- runs containing both growth and damage: 12 / 12;
- sparse cells changed per run: 22–31;
- final health drift: 10 positive, 0 zero, 2 negative;
- every run produced at least one multi-actor shared echo.

These results show mechanism repeatability with outcome variation. They do not show open-ended emergence. The novelty formula, four signal types, consequence function, actor count, and pattern thresholds are authored.

## Browser interaction verification

Tested against the delivered `dist/curiosity.html` bundle:

- clean revision-zero genesis displayed no invented result;
- one-question control exposed a novelty-only machine choice and no outcome label for movement;
- one manual step plus the 64-step loop reached step 65;
- observer result: 23 changed cells, 3 growth events, 5 damage events, 3 bloom cells, 4 scar cells, 7 shared echoes, health drift −3;
- observer patterns: shared echo, bloom scatter, scar scatter, curiosity trail;
- machine panel continued to show only terrain, phase, unseen neighbours, trial counts, and novelty basis;
- exact replay reconstructed all 65 choices and digest prefix `17c825a5a76c`;
- reset returned to zero outcomes and zero receipts;
- no horizontal overflow at the 1348-pixel verification viewport;
- all five controls remained enabled after the loop;
- application-origin browser warnings/errors: none.

## Retained v0.2 result

The relational lab still reproduces player share → Rhea autonomous share → `mutual_aid`, while wait → Rhea request → `unanswered_need`. Its engine and UI were not replaced by Curiosity Garden.

## Truth boundary

Observed: a deterministic novelty policy can drive sparse, replayable changes with mixed observer-visible consequences while outcome labels remain outside the actor input.

Not proven:

- subjective curiosity or machine desire;
- that the changes are useful, wise, fun, or narratively meaningful;
- long-term ecological stability or open-ended novelty;
- better results than efficiency-driven control policies;
- millions of active actors or changed cells;
- networked multiplayer, portable human states, or OS/USB behavior;
- mobile browser interaction in the supervised browser;
- GitHub CI, PR, merge, release, or canon state.
