# Foundation Receipt

```text
foundation: AXM State Floor v0.1.0
source archive SHA-256: bbdeefe7cecc79bd9096d7c9db6a2462833b1319ec8e350eef2bb121a0b7854d
reverified at: 2026-09-01T03:49:32Z
freshness TTL at use: 1 hour
volatility class: active local build
status at use: LIVE
foundation tests at use: 8/8 PASS
reverified before dependent build: yes
```

The complete foundation source, original benchmark evidence, limitations, and pre-hash-cache results are bundled under `foundation/axm-state-floor/`.

Freshness establishes that Sentinel used the intended current local foundation. It does not independently prove the foundation's architectural claims.
